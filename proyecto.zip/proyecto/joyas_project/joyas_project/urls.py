from django.contrib import admin
from django.urls import path 
from  joyas_app.views import JoyaListado, JoyaDetalle, JoyaCrear, JoyaActualizar, JoyaEliminar


urlpatterns = [

    path('admin/', admin.site.urls),

    # La ruta 'leer' en donde listamos todos los registros o arepas de la Base de Datos
    path('joyas/', JoyaListado.as_view(template_name = "joyas/index.html"), name='leer'),

    # La ruta 'detalles' en donde mostraremos una página con los detalles de un arepas o registro 
    path('joyas/detalle/<int:pk>', JoyaDetalle.as_view(template_name = "joyas/detalles.html"), name='detalles'),

    # La ruta 'crear' en donde mostraremos un formulario para crear un nuevo arepas o registro  
    path('joyas/crear', JoyaCrear.as_view(template_name = "joyas/crear.html"), name='crear'),

    # La ruta 'actualizar' en donde mostraremos un formulario para actualizar un arepas o registro de la Base de Datos 
    path('joyas/editar/<int:pk>', JoyaActualizar.as_view(template_name = "joyas/actualizar.html"), name='actualizar'), 

    # La ruta 'eliminar' que usaremos para eliminar un arepas o registro de la Base de Datos 
    path('joyas/eliminar/<int:pk>', JoyaEliminar.as_view(), name='eliminar'),   
]
