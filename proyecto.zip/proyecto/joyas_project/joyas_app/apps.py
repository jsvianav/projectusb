from django.apps import AppConfig


class JoyasAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'joyas_app'
